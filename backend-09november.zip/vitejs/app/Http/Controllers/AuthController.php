<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Models\User;
use Tymon\JWTAuth\Facades\JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;
use Tymon\JWTAuth\Exceptions\TokenExpiredException;
use Tymon\JWTAuth\Exceptions\TokenInvalidException;
use Auth;
class AuthController extends Controller
{
    public function register(Request $request)
    {
        $this->validate($request, [
            'name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|min:6',
        ]);

        $user = new User();
        $user->name = $request->input('name');
        $user->email = $request->input('email');
        $user->password = bcrypt($request->input('password'));
        $user->save();

        return response()->json(['message' => 'User registered successfully'], 201);
    }

    public function login(Request $request)
    {
        $credentials = $request->only('email', 'password');
    
        if (Auth::attempt($credentials)) {
            $user = Auth::user();
            $token = JWTAuth::fromUser($user);
            $user->update(['jwt_token' => $token]);
            return response()->json([
                'accessToken' => $token,
                'user' => $user,
            ], 200);            
        } else {
            return response()->json(['error' => 'Invalid credentials'], 401);
        }
    }
    public function refresh()
    {
        try {
            $newToken = JWTAuth::refresh(JWTAuth::getToken());
            return response()->json(['token' => $newToken]);
        } catch (TokenInvalidException $e) {
            return response()->json(['error' => 'Invalid token'], 400);
        } catch (TokenExpiredException $e) {
            return response()->json(['error' => 'Token has expired'], 400);
        }
    }
    public function authme(Request $request){
        try {
            $user = $request->user();
            $token = $request->bearerToken();
            $findtoken = User::where('jwt_token', $token)->first();
            return response()->json($findtoken, 200);
        } catch (\Exception $e) {
            return response()->json(['error' => 'Unauthorized'], 401);
        }
    }
}
